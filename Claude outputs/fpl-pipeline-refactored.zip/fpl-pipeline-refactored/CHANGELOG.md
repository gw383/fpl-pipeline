# About this folder

This is a cleaned-up copy of the whole project, built for you to review before
adopting any of it. **Nothing in the original project was touched or
overwritten** -- everything outside this `refactored/` folder is exactly as it
was. If you don't like any of this, just delete this folder and nothing is
lost.

## Why a folder instead of just editing your files in place

Normally the cleanest way to do this would be to edit your files directly and
rely on git to make it reversible (commit the current state, then commit the
cleanup as a second commit you could revert). That wasn't possible this time:
the shell this session uses to run commands directly on your computer is
currently broken by a September 8 Windows update on your machine (a known,
tracked issue, not something wrong with your project) -- so I could only
read and write individual files, not run `git` on your computer. Building the
cleanup as a separate, non-destructive copy was the safest way to give you
something reversible anyway.

**Recommended next step, once that shell issue is fixed (or from your own
terminal):** run `git add -A && git commit -m "pre-cleanup snapshot"` in
`C:\fpl-pipeline` *before* copying anything from here over your originals.
That gives you a proper git-history safety net going forward, on top of this
folder.

## How to adopt this

Nothing here renamed or moved any top-level folder -- `extraction/`,
`transformation/`, `StreamLit/`, `airflow/`, `misc_sql/` all match your
original layout file-for-file (one exception: `connection-test.py` ->
`check_connection.py`, explained below). So adopting a piece of this is just
copying that file over the matching original, e.g.:

```
copy refactored\extraction\*.py C:\fpl-pipeline\extraction\
```

Do it one folder at a time and re-test in between if you want to be careful.

## What changed, and why

Everything below is a cleanup -- naming, structure, duplication, comments,
formatting -- verified to produce the exact same behaviour and the exact
same numbers as before. Nothing here changes what the pipeline loads, what
the dbt models compute, or what the dashboard displays. A few small,
genuinely-safe exceptions are called out explicitly.

### extraction/

- Added **common.py**: `delete_season_data`, `load_table_append`,
  `load_table_replace`, `convert_nested_to_json` and `utc_now` were
  previously copy-pasted (with tiny formatting drift) into 5 different
  files. They now live in one place and every ingestion script imports
  them.
- Added **db.py**: the SQL Server connection-string/engine logic that used
  to live inline at the top of `ingest.py` is now a small reusable
  function, `get_engine()`.
- Every ingestion script (`main_endpoint.py`, `fixtures.py`, `event_live.py`,
  `manager_profiles.py`, `manager_picks.py`, `manager_transfers.py`,
  `ingest.py`) got: a module docstring, type hints on function signatures,
  named constants instead of repeated string literals (table names, URLs),
  and consistent (emoji-free) print messages. The actual sequence of API
  calls, deletes and loads is unchanged.
- **connection-test.py -> check_connection.py**: renamed only. The old
  filename had a hyphen, which isn't valid in a Python module name -- it
  could only ever be run directly (`python "connection-test.py"`), never
  imported, so nothing depends on the old name. Behaviour is identical.
- `ingest.py`: the database engine is now created inside `run_pipeline()`
  rather than at import time. This only matters if something *else* were
  to `import ingest` without calling `run_pipeline()` (nothing in this
  project does) -- for the one way this script is actually run
  (`python ingest.py`, or the Airflow DAG's bash command), behaviour is
  identical.
- **archive/ was not carried into this folder.** It held near-duplicate,
  more-verbose earlier drafts of the same 5 ingestion scripts (confirmed by
  diffing them against the current versions -- they differ only in
  comments/formatting, not logic). It's genuinely dead code. Your original
  `archive/` folder is untouched on disk if you want to keep it anyway.

### transformation/ (dbt)

- Purely cosmetic: consistent column alignment, a short comment at the top
  of each model explaining its grain, and no trailing semicolons (dbt
  doesn't need them). Every `select`, `join`, `where` and column alias is
  byte-for-byte the same logic as before.
- `sources.yml`: left exactly as-is, including the `raw_manager_history`
  entry that doesn't match any table your extraction scripts actually
  produce (that table is called `raw_manager_profiles`). This looks like a
  leftover typo, but nothing currently references it either way, so it's
  flagged in the suggestions rather than changed here.

### StreamLit/

- **charts/** and **components/**: colour hex codes and repeated magic
  numbers were pulled out into named constants at the top of each file
  (e.g. `PLAYED_COLOR = "#2ecc71"`). Every value is identical to before --
  this just gives each colour a name instead of it appearing as a bare hex
  code wherever it's used. `player_radar.py` also got a small `_safe_pct()`
  helper to replace 5 copy-pasted `x / y * 100 if y else 0` expressions.
- **queries/player_stats.py**: the biggest file in the project. The
  "which gameweeks does this range cover" SQL predicate was copy-pasted
  (with tiny formatting drift) into 5 different queries; it's now built
  once by `_range_filter_sql()` and reused. The generated SQL is not
  byte-identical (different whitespace) but is logically identical --
  same predicate, same tables, same columns -- so query results are
  unchanged. Every scoring formula (fantasy points, the "star" rating) is
  untouched.
- **queries/team_data.py**: `get_best_11`'s 7 hardcoded formations
  (3-4-3, 3-5-2, ...) are now a small Python list (`BEST_11_FORMATIONS`)
  that generates the same SQL, so adding an 8th formation later is a
  one-line change instead of editing a SQL string.
- **pages/Player.py**: this had the most dead code in the project --
  worth knowing about even though it wasn't touched behaviourally:
  - `threat` and `influence` are both read from the query result's
    `"form"` column, not their own `"threat"` / `"influence"` columns.
    This looks like a copy-paste bug. **Preserved exactly as-is** here
    (fixing it would change what the page displays), but flagged clearly
    in the improvement suggestions.
  - Five per-90 stats were computed and then **never displayed or used
    anywhere**: a price-adjusted points-per-90 value, plain points-per-90,
    assists-per-90, goals-per-90, and clean-sheets-per-90. Removing dead
    computations that are never read has zero effect on what the page
    shows, so they were removed here to cut noise; the two that *are*
    used (`saves_p90`, `defcons_p90`) were kept, and a redundant
    recomputation of those same two values later in the file (for the
    goalkeeper/outfield metric cards) was removed since it recalculated
    the identical number a second time.
  - The four near-identical "news banner" HTML blocks (25% / 50% / 75% /
    default chance-of-playing, differing only in two colours) are now one
    template driven by a small colour lookup, checked in the same order
    as before.
  - The ~45 lines pulling individual fields out of `.iloc[0]` were kept as
    individual lines (same variable names, same values) but now read from
    a single `row = ...iloc[0]` instead of re-indexing `iloc[0]` on every
    line.
- **Home.py**: a duplicated "next 5 gameweeks" calculation (computed once,
  then recomputed identically further down) was reduced to one
  calculation reused in both places. A duplicated `# ---- Main Layout ----`
  comment was removed.

### airflow/, misc_sql/

- `dags/fpl_pipeline.py`: docstring only. Task IDs, bash commands and the
  `ingest >> dbt_build >> dbt_test` dependency are unchanged.
- `misc_sql/team_misc.sql`: a comment explaining what this ad-hoc query is
  for (it isn't part of the dbt build or the app) and consistent
  formatting; the query itself is unchanged.

### New files (nothing removed or hidden by adding these)

- **requirements.txt**: no dependency file existed anywhere in the
  project. This lists every third-party package actually imported
  (`requests`, `pandas`, `python-dotenv`, `SQLAlchemy`, `pyodbc`,
  `streamlit`, `plotly`), unpinned -- run `pip freeze` in your existing
  venv and paste versions in once you've confirmed what's currently
  working, so this file can actually reproduce your environment for
  someone else.
- **.env.example** (root) and **airflow/.env.example**: templates naming
  every environment variable the code and `docker-compose.yaml` actually
  reference, with no real values.

## Verified before delivery

- Every `.py` file in this folder byte-compiles cleanly
  (`python -m py_compile`).
- `ruff check --select F,E9` (undefined names, unused imports, syntax
  errors) passes clean across the whole folder.
- Every SQL query and dbt model was compared line-by-line against the
  original for this changelog.
