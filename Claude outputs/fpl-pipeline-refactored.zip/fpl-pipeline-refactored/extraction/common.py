"""Shared ingestion helpers used across the extraction scripts.

Every raw-loading script follows one of two patterns:

* Season-partitioned tables (players, teams, fixtures, gameweeks,
  event-live stats) delete the current season's rows and append the
  freshly-fetched replacement, so re-running mid-season never creates
  duplicates.
* Manager-specific snapshots (profiles, picks, transfers) simply
  replace the whole table, since they only ever need to hold the
  latest pull for a small, hand-maintained list of FPL entry IDs.

Centralising both patterns here means every ingestion script shares
one implementation instead of five near-identical copies.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

import pandas as pd
from sqlalchemy import text
from sqlalchemy.engine import Engine

RAW_SCHEMA = "raw"


def utc_now() -> datetime:
    """Return the current UTC timestamp used to stamp every load."""
    return datetime.now(timezone.utc)


def convert_nested_to_json(df: pd.DataFrame) -> pd.DataFrame:
    """Serialise any dict/list columns in `df` to JSON strings.

    SQL Server has no native column type for nested structures, so any
    column holding dicts or lists (as the FPL API sometimes returns)
    is flattened to JSON text before loading.
    """
    for col in df.columns:
        if df[col].apply(lambda value: isinstance(value, (dict, list))).any():
            df[col] = df[col].apply(
                lambda value: json.dumps(value)
                if isinstance(value, (dict, list))
                else value
            )
    return df


def delete_season_data(engine: Engine, table_name: str, season: str) -> None:
    """Delete existing rows for `season` from raw.`table_name`.

    Called before an append-style load so re-running the pipeline for
    the same season never creates duplicate rows.
    """
    with engine.begin() as conn:
        result = conn.execute(
            text(f"DELETE FROM {RAW_SCHEMA}.{table_name} WHERE season = :season"),
            {"season": season},
        )
        print(
            f"Cleared {season} data from {RAW_SCHEMA}.{table_name} "
            f"({result.rowcount} rows)"
        )


def load_table_append(df: pd.DataFrame, table_name: str, engine: Engine) -> None:
    """Append `df` to raw.`table_name`.

    Used for season-partitioned tables, after `delete_season_data` has
    already removed that season's previous rows.
    """
    df["load_timestamp"] = df["load_timestamp"].astype(str)
    df.to_sql(table_name, engine, schema=RAW_SCHEMA, if_exists="append", index=False)
    print(f"Loaded {RAW_SCHEMA}.{table_name} ({len(df)} rows)")


def load_table_replace(df: pd.DataFrame, table_name: str, engine: Engine) -> None:
    """Replace raw.`table_name` entirely with `df`.

    Used for manager-specific snapshots, which only ever need to hold
    the latest pull rather than a running history.
    """
    df["load_timestamp"] = df["load_timestamp"].astype(str)
    df.to_sql(table_name, engine, schema=RAW_SCHEMA, if_exists="replace", index=False)
    print(f"Loaded {RAW_SCHEMA}.{table_name} ({len(df)} rows)")
