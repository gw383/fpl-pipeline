"""Ingests per-gameweek live player stats ("event/<gw>/live") from the FPL API."""
from __future__ import annotations

import pandas as pd
import requests
from sqlalchemy.engine import Engine

from common import delete_season_data, load_table_append, utc_now
from config import CURRENT_SEASON

TABLE_NAME = "raw_event_live"


def fetch_event_live(gameweek: int) -> dict:
    """Fetch live per-player stats for a single gameweek."""
    url = f"https://fantasy.premierleague.com/api/event/{gameweek}/live/"
    response = requests.get(url, timeout=30)
    response.raise_for_status()
    return response.json()


def event_live(engine: Engine, gameweeks: list[int]) -> None:
    """Ingest live stats for every gameweek in `gameweeks`.

    Gameweeks that haven't been played yet return an empty element
    list from the API and are skipped.
    """
    print(f"Starting event live ingestion ({len(gameweeks)} gameweeks)")

    frames = []
    for gw in gameweeks:
        data = fetch_event_live(gw)
        elements = data.get("elements", [])

        if not elements:
            continue

        df = pd.json_normalize(elements)
        df["event_id"] = gw
        df["season"] = CURRENT_SEASON
        df["load_timestamp"] = utc_now()
        frames.append(df)

        print(f"Loaded GW {gw}")

    if not frames:
        print("No event live data returned")
        return

    combined = pd.concat(frames, ignore_index=True)
    combined.columns = [col.lower().replace(" ", "_") for col in combined.columns]

    delete_season_data(engine, TABLE_NAME, CURRENT_SEASON)
    load_table_append(combined, TABLE_NAME, engine)

    print("Event live ingestion complete")
