"""Database connection for the Streamlit reporting layer.

Uses Windows-integrated authentication against the local SQL Server
instance, since the dashboard runs on the same machine as the
database. This is intentionally different from the extraction
pipeline's connection (extraction/db.py), which runs inside Docker and
authenticates with SQL Server credentials instead -- see the project
README for why the two entry points need different auth strategies.
"""
from urllib.parse import quote_plus

from sqlalchemy import create_engine

CONNECTION_STRING = (
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=localhost;"
    "DATABASE=FPL;"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)

engine = create_engine(
    f"mssql+pyodbc:///?odbc_connect={quote_plus(CONNECTION_STRING)}"
)
